import React, { useState, useMemo, useEffect } from "react";
import {
  User, Stethoscope, Building2, MonitorPlay, ChevronRight, ChevronLeft,
  Clock, CheckCircle2, XCircle, AlertTriangle, MessageCircle, Send,
  ShieldCheck, FileText, Sparkles, Users, Activity, TrendingUp,
  Bell, BellRing, ChevronDown, Lock, Unlock, Check, Phone, Upload, X, UserPlus, Minus, Plus,
} from "lucide-react";

// ---------------- Design tokens ----------------
const C = {
  void: "#0A0A0C",
  surface: "#161619",
  raised: "#1E1E22",
  border: "#2B2B30",
  text: "#F5F3EE",
  muted: "#93929A",
  faint: "#5C5B62",
  gold: "#C9A467",
  goldSoft: "rgba(201,164,103,0.14)",
  teal: "#4FAFA3",
  tealSoft: "rgba(79,175,163,0.14)",
  green: "#5FBF8B",
  greenSoft: "rgba(95,191,139,0.14)",
  amber: "#E0A94D",
  amberSoft: "rgba(224,169,77,0.14)",
  red: "#E0615A",
  redSoft: "rgba(224,97,90,0.14)",
  purple: "#B79CD0",
  purpleSoft: "rgba(183,156,208,0.14)",
};

const FONT_BODY = "'Inter', 'Noto Sans Devanagari', sans-serif";
const FONT_DISPLAY = "'Fraunces', 'Noto Sans Devanagari', serif";

const STR = {
  en: {
    appName: "Smart Hospital",
    tabPatient: "Patient App", tabDoctor: "Doctor Dashboard", tabAdmin: "Admin Dashboard", tabDisplay: "Hospital Display",
    goodMorning: "Good morning", currentAppt: "Current Appointment",
    tokensAhead: "patients ahead", estWait: "Estimated wait", status: "Status", waiting: "Waiting",
    approaching: "Your turn is approaching", proceedTo: "Please proceed to",
    bookSlot: "Book a Slot", bookSlotSub: "Find the right care, fast",
    seeDoc: "See a Doctor", seeDocSub: "Pick a doctor, see live wait times",
    knowProblem: "Know Your Problem", knowProblemSub: "Describe symptoms, AI finds the right doctor",
    seeConsultant: "See a Consultant", seeConsultantSub: "Talk to a general physician first",
    walkIn: "Walk-in / Get Token", walkInSub: "No booking? Get a token on arrival",
    vault: "Medical Vault", vaultSub: "Private, consent-controlled",
    aiIntro: "Hi, tell me what's bothering you. I'll ask a few questions and match you with the right doctor.",
    aiDisclaimer: "This AI gives preliminary guidance to help you reach the right doctor. It does not replace a medical evaluation.",
    aiPlaceholder: "Type your symptoms...", aiSuggested: "Based on what you've shared, I'd suggest:",
    aiBook: "Book this doctor", back: "Back", min: "min",
    live: "LIVE", nowServing: "NOW SERVING", next: "NEXT", token: "Token",
    todaysSummary: "Today", patients: "Patients", completed: "Completed", noShow: "No-show",
    currentToken: "Current token", nextPatient: "Next Patient", queue: "Queue",
    requestAccess: "Request Medical Vault Access", accessGranted: "Access Granted",
    accessPending: "Requesting access from patient...", chiefComplaint: "Chief complaint",
    knownConditions: "Known conditions", allergy: "Allergy", currentMeds: "Current medicines",
    reports: "Relevant reports", markPriority: "Mark priority", complete: "Complete consultation",
    liveHospital: "Live Hospital", today: "Today", currentlyWaiting: "Currently waiting",
    doctorsAvailable: "Doctors available", onLeave: "On leave", avgWait: "Avg. OPD wait",
    departmentLoad: "Department Load", mostCrowded: "Most crowded",
    labQueue: "Pathology queue", pharmQueue: "Pharmacy queue",
    allow: "Allow", deny: "Deny", accessRequest: "is requesting access to your medical records",
    normal: "Normal", priority: "Priority", emergency: "Emergency",
    role: "Role Select", whoAmI: "Who are you?", whoSub: "Choose how you'd like to enter",
    doctorRole: "Doctor", patientRole: "Patient", doctorRoleSub: "Manage your queue & patients", patientRoleSub: "Book slots & manage your health",
    mobileTitle: "Enter mobile number", mobileSub: "We'll send a one-time code to verify", sendOtp: "Send OTP",
    otpTitle: "Verify OTP", otpSub: "Enter the 6-digit code sent to", verify: "Verify & Continue",
    personalTitle: "Personal details", personalSub: "This helps doctors treat you better",
    nameField: "Full name", ageField: "Age", sexField: "Sex", bloodField: "Blood group", emergencyField: "Emergency contact",
    continueBtn: "Continue", historyTitle: "Medical history",
    historySub: "Scan or upload past reports, prescriptions & medicines — this becomes your personal vault",
    scanDoc: "Scan a document", skipForNow: "Skip for now", finish: "Finish setup & enter app",
    doctorsToday: "patients ahead", bookNow: "Book slot", consultTitle: "General Consultation",
    consultBody: "You'll be seen by the next available general physician — no need to know your exact issue beforehand. They'll examine you and refer you onward if needed.",
    consultCta: "Confirm consultation", booked: "Slot booked!", bookedSub: "You'll get a reminder before your turn", doneClose: "Done",
    professionalTitle: "Professional details", professionalSub: "Hospitals use this to verify and activate your profile",
    qualification: "Qualification", specialization: "Specialization", regNumber: "Medical registration number",
    stateCouncil: "State Medical Council", experience: "Years of experience", hospitalAffiliation: "Hospital affiliation", department: "Department",
    submitForVerification: "Submit for verification", pendingTitle: "Pending Verification",
    pendingSub: "Your details have been submitted. The hospital admin needs to approve your profile before you can access the doctor dashboard.",
    pendingBadge: "Pending Verification", simulateApproval: "Simulate admin approval (demo)",
    alarmTitle: "Your turn is almost here", alarmBody: "is about", alarmBody2: "min away. Please head to the hospital now.",
    dismiss: "Dismiss", tokenInMin: "min to your token",
    doctorRoster: "Doctor Roster", markLeave: "Mark on leave", markAvailable: "Mark available",
    pendingApprovals: "Pending Doctor Approvals", noPendingApprovals: "No pending approvals",
    approve: "Approve", reject: "Reject", adjustLoad: "Adjust load",
  },
  hi: {
    appName: "स्मार्ट हॉस्पिटल",
    tabPatient: "पेशेंट ऐप", tabDoctor: "डॉक्टर डैशबोर्ड", tabAdmin: "एडमिन डैशबोर्ड", tabDisplay: "हॉस्पिटल डिस्प्ले",
    goodMorning: "सुप्रभात", currentAppt: "वर्तमान अपॉइंटमेंट",
    tokensAhead: "मरीज़ आगे हैं", estWait: "अनुमानित प्रतीक्षा", status: "स्थिति", waiting: "प्रतीक्षा में",
    approaching: "आपकी बारी आने वाली है", proceedTo: "कृपया यहाँ जाएँ",
    bookSlot: "स्लॉट बुक करें", bookSlotSub: "सही इलाज, तुरंत",
    seeDoc: "डॉक्टर देखें", seeDocSub: "डॉक्टर चुनें, लाइव वेट टाइम देखें",
    knowProblem: "समस्या जानें", knowProblemSub: "लक्षण बताएँ, AI सही डॉक्टर बताएगा",
    seeConsultant: "सलाहकार से मिलें", seeConsultantSub: "पहले जनरल फिज़िशियन से बात करें",
    walkIn: "वॉक-इन / टोकन लें", walkInSub: "बुकिंग नहीं है? आते ही टोकन लें",
    vault: "मेडिकल वॉल्ट", vaultSub: "निजी, सहमति-नियंत्रित",
    aiIntro: "नमस्ते, बताइए क्या तकलीफ़ है। मैं कुछ सवाल पूछूँगा और सही डॉक्टर बताऊँगा।",
    aiDisclaimer: "यह AI केवल प्रारंभिक मार्गदर्शन देता है, डॉक्टर की जाँच का विकल्प नहीं है।",
    aiPlaceholder: "अपने लक्षण लिखें...", aiSuggested: "आपकी बताई बातों के आधार पर, मेरा सुझाव है:",
    aiBook: "इस डॉक्टर को बुक करें", back: "वापस", min: "मिनट",
    live: "लाइव", nowServing: "अभी सेवा में", next: "अगला", token: "टोकन",
    todaysSummary: "आज", patients: "मरीज़", completed: "पूर्ण", noShow: "अनुपस्थित",
    currentToken: "वर्तमान टोकन", nextPatient: "अगला मरीज़", queue: "कतार",
    requestAccess: "मेडिकल वॉल्ट एक्सेस माँगें", accessGranted: "एक्सेस मिल गया",
    accessPending: "मरीज़ से अनुमति माँगी जा रही है...", chiefComplaint: "मुख्य शिकायत",
    knownConditions: "ज्ञात स्थितियाँ", allergy: "एलर्जी", currentMeds: "वर्तमान दवाइयाँ",
    reports: "संबंधित रिपोर्ट्स", markPriority: "प्राथमिकता दें", complete: "परामर्श पूर्ण करें",
    liveHospital: "लाइव हॉस्पिटल", today: "आज", currentlyWaiting: "प्रतीक्षारत",
    doctorsAvailable: "उपलब्ध डॉक्टर", onLeave: "अवकाश पर", avgWait: "औसत OPD प्रतीक्षा",
    departmentLoad: "विभाग भार", mostCrowded: "सबसे व्यस्त",
    labQueue: "पैथोलॉजी कतार", pharmQueue: "फार्मेसी कतार",
    allow: "अनुमति दें", deny: "मना करें", accessRequest: "आपके मेडिकल रिकॉर्ड्स की एक्सेस माँग रहे हैं",
    normal: "सामान्य", priority: "प्राथमिकता", emergency: "आपातकाल",
    role: "भूमिका चुनें", whoAmI: "आप कौन हैं?", whoSub: "आगे बढ़ने का तरीका चुनें",
    doctorRole: "डॉक्टर", patientRole: "मरीज़", doctorRoleSub: "अपनी कतार और मरीज़ों को संभालें", patientRoleSub: "स्लॉट बुक करें व सेहत का ध्यान रखें",
    mobileTitle: "मोबाइल नंबर डालें", mobileSub: "पुष्टि के लिए एक कोड भेजा जाएगा", sendOtp: "OTP भेजें",
    otpTitle: "OTP सत्यापित करें", otpSub: "6 अंकों का कोड यहाँ भेजा गया", verify: "सत्यापित करें",
    personalTitle: "व्यक्तिगत जानकारी", personalSub: "इससे डॉक्टर आपका बेहतर इलाज कर पाएँगे",
    nameField: "पूरा नाम", ageField: "उम्र", sexField: "लिंग", bloodField: "ब्लड ग्रुप", emergencyField: "इमरजेंसी संपर्क",
    continueBtn: "आगे बढ़ें", historyTitle: "मेडिकल हिस्ट्री",
    historySub: "पुरानी रिपोर्ट्स, दवाइयाँ स्कैन करें — यही आपका पर्सनल वॉल्ट बनेगा",
    scanDoc: "दस्तावेज़ स्कैन करें", skipForNow: "अभी छोड़ें", finish: "सेटअप पूरा करें और ऐप खोलें",
    doctorsToday: "मरीज़ आगे हैं", bookNow: "स्लॉट बुक करें", consultTitle: "जनरल परामर्श",
    consultBody: "अगले उपलब्ध जनरल फिज़िशियन आपको देखेंगे — पहले से समस्या पता होना ज़रूरी नहीं। वे जाँच कर आगे रेफर करेंगे अगर ज़रूरत हो।",
    consultCta: "परामर्श पक्का करें", booked: "स्लॉट बुक हो गया!", bookedSub: "आपकी बारी से पहले याद दिलाया जाएगा", doneClose: "ठीक है",
    professionalTitle: "पेशेवर जानकारी", professionalSub: "अस्पताल इससे आपकी प्रोफ़ाइल सत्यापित व सक्रिय करता है",
    qualification: "योग्यता", specialization: "विशेषज्ञता", regNumber: "मेडिकल रजिस्ट्रेशन नंबर",
    stateCouncil: "राज्य मेडिकल काउंसिल", experience: "अनुभव (वर्ष)", hospitalAffiliation: "अस्पताल संबद्धता", department: "विभाग",
    submitForVerification: "सत्यापन हेतु जमा करें", pendingTitle: "सत्यापन लंबित",
    pendingSub: "आपकी जानकारी जमा हो गई है। डॉक्टर डैशबोर्ड एक्सेस करने से पहले हॉस्पिटल एडमिन को आपकी प्रोफ़ाइल मंज़ूर करनी होगी।",
    pendingBadge: "सत्यापन लंबित", simulateApproval: "एडमिन मंज़ूरी सिमुलेट करें (डेमो)",
    alarmTitle: "आपकी बारी नज़दीक है", alarmBody: "लगभग", alarmBody2: "मिनट दूर है। कृपया अभी अस्पताल के लिए निकलें।",
    dismiss: "बंद करें", tokenInMin: "मिनट में आपका टोकन",
    doctorRoster: "डॉक्टर सूची", markLeave: "अवकाश पर चिह्नित करें", markAvailable: "उपलब्ध चिह्नित करें",
    pendingApprovals: "लंबित डॉक्टर स्वीकृतियाँ", noPendingApprovals: "कोई लंबित स्वीकृति नहीं",
    approve: "स्वीकृत करें", reject: "अस्वीकृत करें", adjustLoad: "भार समायोजित करें",
  },
};

const NAMES = ["Rahul Kumar", "Sunita Devi", "Amit Verma", "Kavita Joshi", "Deepak Yadav", "Pooja Mishra", "Sanjay Gupta", "Neha Singh", "Ravi Prajapati", "Anita Kumari", "Manoj Tiwari", "Shreya Pandey"];

function makeQueue(demoName = "Rahul Kumar") {
  // tokens 41-52, our demo patient is token 48
  const arr = [];
  for (let i = 0; i < 12; i++) {
    const tokenNum = 41 + i;
    arr.push({
      tokenNum,
      name: tokenNum === 48 ? demoName : NAMES[(i + 3) % NAMES.length],
      age: 22 + ((i * 7) % 55),
      priority: tokenNum === 45 ? "priority" : "normal",
      status: "waiting",
      duration: null,
      isDemoPatient: tokenNum === 48,
    });
  }
  return arr;
}

const DOCTOR_LIST = [
  { name: "Dr. Sharma", spec: "General Medicine", specHi: "जनरल मेडिसिन", ahead: 3, avg: 10 },
  { name: "Dr. Anjali Rao", spec: "Cardiology", specHi: "हृदय रोग विशेषज्ञ", ahead: 6, avg: 12 },
  { name: "Dr. Meera Iyer", spec: "Dermatology", specHi: "त्वचा रोग विशेषज्ञ", ahead: 1, avg: 8 },
  { name: "Dr. Farhan Ali", spec: "Orthopedics", specHi: "हड्डी रोग विशेषज्ञ", ahead: 4, avg: 15 },
  { name: "Dr. Priya Nair", spec: "Pediatrics", specHi: "बाल रोग विशेषज्ञ", ahead: 2, avg: 10 },
];

const DEPARTMENTS = [
  { name: "General Medicine", nameHi: "जनरल मेडिसिन", waiting: 12, doctorsOn: 3 },
  { name: "Cardiology", nameHi: "हृदय रोग", waiting: 6, doctorsOn: 2 },
  { name: "Orthopedics", nameHi: "हड्डी रोग", waiting: 8, doctorsOn: 2 },
  { name: "Pediatrics", nameHi: "बाल रोग", waiting: 4, doctorsOn: 1 },
  { name: "Dermatology", nameHi: "त्वचा रोग", waiting: 3, doctorsOn: 1 },
];

function Segmented({ tabs, active, onChange }) {
  return (
    <div style={{ display: "flex", gap: 4, background: C.raised, border: `1px solid ${C.border}`, borderRadius: 14, padding: 4 }}>
      {tabs.map(tb => (
        <button key={tb.key} className="tap" onClick={() => onChange(tb.key)} style={{
          display: "flex", alignItems: "center", gap: 6, border: "none", cursor: "pointer",
          borderRadius: 10, padding: "9px 13px", fontSize: 12.5, fontWeight: 600,
          background: active === tb.key ? C.gold : "transparent", color: active === tb.key ? "#1a1408" : C.muted,
          whiteSpace: "nowrap",
        }}>
          <tb.Icon size={14} />{tb.label}
        </button>
      ))}
    </div>
  );
}

function StatusPill({ label, color, bg }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 5, background: bg, color, fontSize: 11, fontWeight: 600, borderRadius: 20, padding: "3px 9px" }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: color }} />{label}
    </span>
  );
}

function Card({ children, style }) {
  return <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 16, ...style }}>{children}</div>;
}

function Field({ label, value, onChange, placeholder }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ fontSize: 11.5, color: C.muted, marginBottom: 5, fontWeight: 500 }}>{label}</div>
      <input value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)}
        style={{ width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 11, padding: "11px 12px", color: C.text, fontSize: 13.5, fontFamily: "inherit" }} />
    </div>
  );
}

function PhoneShell({ children }) {
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div style={{ width: 390, background: C.void, border: `1px solid ${C.border}`, borderRadius: 32, overflow: "hidden", boxShadow: "0 30px 80px rgba(0,0,0,0.5)" }}>
        <div style={{ minHeight: 640, display: "flex", flexDirection: "column", padding: "22px 20px" }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// ==================================================================================
function MainApp({ lang, setLang, initialName, initialTab }) {
  const t = STR[lang];

  // ---- Shared live state ----
  const [queue, setQueue] = useState(() => makeQueue(initialName));
  const [currentIdx, setCurrentIdx] = useState(4); // index into queue currently being served
  const [durations, setDurations] = useState([9, 11, 8, 10]); // rolling recent durations
  const rollingAvg = useMemo(() => Math.round(durations.reduce((a, b) => a + b, 0) / durations.length), [durations]);

  const demoPatientIdx = queue.findIndex(q => q.isDemoPatient);
  const etaFor = (idx) => Math.max(0, (idx - currentIdx)) * rollingAvg;

  const callNext = () => {
    setQueue(q => {
      const copy = [...q];
      if (currentIdx < copy.length) copy[currentIdx] = { ...copy[currentIdx], status: "completed" };
      if (currentIdx + 1 < copy.length) copy[currentIdx + 1] = { ...copy[currentIdx + 1], status: "in-consultation" };
      return copy;
    });
    const newDuration = 7 + Math.floor(Math.random() * 8);
    setDurations(d => [...d.slice(-4), newDuration]);
    setCurrentIdx(i => Math.min(i + 1, queue.length - 1));
    setVaultAccess(false);
  };

  const markPriority = (idx) => {
    setQueue(q => {
      const copy = [...q];
      const item = { ...copy[idx], priority: "priority" };
      copy.splice(idx, 1);
      const insertAt = currentIdx + 1;
      copy.splice(insertAt, 0, item);
      return copy;
    });
  };

  const [vaultAccess, setVaultAccess] = useState(false);
  const [vaultRequesting, setVaultRequesting] = useState(false);

  const [tab, setTab] = useState(initialTab || "patient");

  const tabs = [
    { key: "patient", label: t.tabPatient, Icon: User },
    { key: "doctor", label: t.tabDoctor, Icon: Stethoscope },
    { key: "admin", label: t.tabAdmin, Icon: Building2 },
    { key: "display", label: t.tabDisplay, Icon: MonitorPlay },
  ];

  return (
    <div style={{ minHeight: "100vh", background: `radial-gradient(120% 120% at 50% 0%, #1a1a1e 0%, ${C.void} 55%)`, fontFamily: FONT_BODY, color: C.text }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        input:focus, button:focus { outline: none; }
        .fadein { animation: fadein .3s ease both; }
        @keyframes fadein { from { opacity:0; transform: translateY(6px);} to {opacity:1; transform:none;} }
        .tap { transition: transform .12s ease, background .15s ease; }
        .tap:active { transform: scale(0.97); }
        ::-webkit-scrollbar { height: 6px; width: 6px; }
        ::-webkit-scrollbar-thumb { background: #2b2b30; border-radius: 3px; }
      `}</style>

      {/* Top bar */}
      <div style={{ position: "sticky", top: 0, zIndex: 10, background: "rgba(10,10,12,0.85)", backdropFilter: "blur(10px)", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: 8, background: C.gold, display: "flex", alignItems: "center", justifyContent: "center", color: "#1a1408" }}>
              <Sparkles size={15} />
            </div>
            <div style={{ fontFamily: FONT_DISPLAY, fontWeight: 600, fontSize: 16 }}>{t.appName}</div>
          </div>
          <Segmented tabs={tabs} active={tab} onChange={setTab} />
          <div style={{ display: "flex", background: C.raised, border: `1px solid ${C.border}`, borderRadius: 20, padding: 3 }}>
            {["en", "hi"].map(l => (
              <button key={l} className="tap" onClick={() => setLang(l)} style={{
                border: "none", cursor: "pointer", borderRadius: 16, padding: "5px 11px", fontSize: 11.5, fontWeight: 600,
                background: lang === l ? C.gold : "transparent", color: lang === l ? "#1a1408" : C.muted,
              }}>{l === "en" ? "EN" : "हिं"}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "24px 20px 60px" }}>
        {tab === "patient" && <PatientView t={t} lang={lang} queue={queue} demoPatientIdx={demoPatientIdx} currentIdx={currentIdx} etaFor={etaFor} rollingAvg={rollingAvg} />}
        {tab === "doctor" && <DoctorView t={t} lang={lang} queue={queue} currentIdx={currentIdx} callNext={callNext} rollingAvg={rollingAvg}
          vaultAccess={vaultAccess} vaultRequesting={vaultRequesting} setVaultRequesting={setVaultRequesting} setVaultAccess={setVaultAccess} markPriority={markPriority} />}
        {tab === "admin" && <AdminView t={t} lang={lang} queue={queue} currentIdx={currentIdx} rollingAvg={rollingAvg} />}
        {tab === "display" && <DisplayView t={t} lang={lang} queue={queue} currentIdx={currentIdx} />}
      </div>
    </div>
  );
}

// ==================================================================================
function PatientView({ t, lang, queue, demoPatientIdx, currentIdx, etaFor, rollingAvg }) {
  const [screen, setScreen] = useState("home"); // home, book, ai, vault, seedoc, consultant, booked
  const [chat, setChat] = useState([{ from: "ai", text: STR[lang].aiIntro }]);
  const [chatInput, setChatInput] = useState("");
  const [suggested, setSuggested] = useState(null);
  const [bookedWith, setBookedWith] = useState(null);
  const me = queue[demoPatientIdx];
  const eta = etaFor(demoPatientIdx);
  const approaching = demoPatientIdx - currentIdx <= 2 && me?.status !== "completed";

  const [showAlarm, setShowAlarm] = useState(false);
  const [alarmFiredForEta, setAlarmFiredForEta] = useState(null);
  useEffect(() => {
    if (me?.status !== "completed" && eta <= 10 && eta >= 0 && alarmFiredForEta === null) {
      setShowAlarm(true);
      setAlarmFiredForEta(eta);
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.28, 0.56].forEach(t0 => {
          const osc = ctx.createOscillator(); const gain = ctx.createGain();
          osc.connect(gain); gain.connect(ctx.destination);
          osc.frequency.value = 880; osc.type = "sine";
          gain.gain.setValueAtTime(0.001, ctx.currentTime + t0);
          gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + t0 + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t0 + 0.22);
          osc.start(ctx.currentTime + t0); osc.stop(ctx.currentTime + t0 + 0.24);
        });
      } catch (e) { /* audio not available in this environment */ }
    }
  }, [eta, me?.status, alarmFiredForEta]);

  const sendChat = () => {
    if (!chatInput.trim()) return;
    setChat(c => [...c, { from: "user", text: chatInput }]);
    const turns = chat.filter(m => m.from === "user").length;
    setChatInput("");
    setTimeout(() => {
      if (turns === 0) setChat(c => [...c, { from: "ai", text: lang === "hi" ? "समझ गया। क्या बुखार या दर्द भी है? कब से है?" : "Got it — any fever or pain with it? Since when?" }]);
      else if (turns === 1) setChat(c => [...c, { from: "ai", text: lang === "hi" ? "ठीक है। एक आखिरी सवाल — क्या यह पहले भी हुआ है?" : "Noted. One last thing — has this happened before?" }]);
      else { setSuggested({ name: "Dr. Sharma", spec: "General Medicine", specHi: "जनरल मेडिसिन" }); setChat(c => [...c, { from: "ai", text: STR[lang].aiSuggested }]); }
    }, 650);
  };

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div style={{ width: 390, background: C.void, border: `1px solid ${C.border}`, borderRadius: 32, overflow: "hidden", boxShadow: "0 30px 80px rgba(0,0,0,0.5)", position: "relative" }}>

        {showAlarm && (
          <div className="fadein" style={{
            position: "absolute", top: 14, left: 14, right: 14, zIndex: 20,
            background: `linear-gradient(135deg, ${C.amber} 0%, #b8842f 100%)`, borderRadius: 16, padding: 14,
            boxShadow: "0 12px 30px rgba(224,169,77,0.35)",
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: "rgba(0,0,0,0.18)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <BellRing size={17} color="#1a1408" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ color: "#1a1408", fontSize: 13.5, fontWeight: 700 }}>{t.alarmTitle}</div>
                <div style={{ color: "#3a2e14", fontSize: 12, marginTop: 2, lineHeight: 1.4 }}>
                  {t.token} #{me?.tokenNum} {t.alarmBody} {eta} {t.alarmBody2}
                </div>
              </div>
              <button className="tap" onClick={() => setShowAlarm(false)} style={{ background: "rgba(0,0,0,0.15)", border: "none", borderRadius: 8, width: 24, height: 24, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}>
                <X size={13} color="#1a1408" />
              </button>
            </div>
            <button className="tap" onClick={() => setShowAlarm(false)} style={{ width: "100%", marginTop: 10, background: "rgba(0,0,0,0.18)", border: "none", borderRadius: 10, padding: "7px 0", color: "#1a1408", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>{t.dismiss}</button>
          </div>
        )}

        <div style={{ minHeight: 640, display: "flex", flexDirection: "column", padding: "22px 20px" }}>

          {screen !== "home" && (
            <button className="tap" onClick={() => setScreen("home")} style={{ alignSelf: "flex-start", background: C.raised, border: `1px solid ${C.border}`, borderRadius: 10, width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", color: C.text, cursor: "pointer", marginBottom: 14 }}>
              <ChevronLeft size={17} />
            </button>
          )}

          {screen === "home" && (
            <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
              <div style={{ fontSize: 12, color: C.muted }}>{t.goodMorning}</div>
              <div style={{ fontSize: 22, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 18 }}>{me?.name}</div>

              <Card style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: 1 }}>{t.currentAppt}</div>
                  {approaching ? <StatusPill label={t.approaching} color={C.amber} bg={C.amberSoft} /> : <StatusPill label={t.waiting} color={C.muted} bg={C.raised} />}
                </div>
                <div style={{ fontSize: 16, fontWeight: 600 }}>Dr. Sharma</div>
                <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 12 }}>{lang === "hi" ? "जनरल मेडिसिन" : "General Medicine"}</div>
                <div style={{ display: "flex", gap: 20 }}>
                  <div>
                    <div style={{ fontSize: 20, fontFamily: "'JetBrains Mono'", color: C.gold, fontWeight: 600 }}>#{me?.tokenNum}</div>
                    <div style={{ fontSize: 10.5, color: C.faint }}>{t.token}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 20, fontFamily: "'JetBrains Mono'", fontWeight: 600 }}>{Math.max(0, demoPatientIdx - currentIdx)}</div>
                    <div style={{ fontSize: 10.5, color: C.faint }}>{t.tokensAhead}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 20, fontFamily: "'JetBrains Mono'", fontWeight: 600, color: C.teal }}>~{eta} {t.min}</div>
                    <div style={{ fontSize: 10.5, color: C.faint }}>{t.estWait}</div>
                  </div>
                </div>
                {approaching && (
                  <div style={{ marginTop: 12, background: C.amberSoft, borderRadius: 10, padding: 10, fontSize: 12, color: C.amber }}>
                    {t.proceedTo}: General Medicine — OPD Room 204
                  </div>
                )}
              </Card>

              <button className="tap" onClick={() => setScreen("book")} style={{ width: "100%", textAlign: "left", border: "none", cursor: "pointer", borderRadius: 18, padding: 18, marginBottom: 12, background: `linear-gradient(135deg, ${C.gold} 0%, #a9824a 100%)` }}>
                <Sparkles size={16} color="#1a1408" style={{ marginBottom: 8 }} />
                <div style={{ color: "#1a1408", fontSize: 16, fontWeight: 700, fontFamily: FONT_DISPLAY }}>{t.bookSlot}</div>
                <div style={{ color: "#3a2e14", fontSize: 11.5, marginTop: 2 }}>{t.bookSlotSub}</div>
              </button>

              <button className="tap" onClick={() => setScreen("vault")} style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, textAlign: "left", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 14, cursor: "pointer" }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: C.tealSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.teal }}><ShieldCheck size={17} /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600 }}>{t.vault}</div>
                  <div style={{ fontSize: 11.5, color: C.muted }}>{t.vaultSub}</div>
                </div>
                <ChevronRight size={16} color={C.faint} />
              </button>
              <div style={{ flex: 1 }} />
            </div>
          )}

          {screen === "book" && (
            <div className="fadein">
              <div style={{ fontSize: 20, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 4 }}>{t.bookSlot}</div>
              <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 18 }}>{t.bookSlotSub}</div>
              {[
                { label: t.seeDoc, sub: t.seeDocSub, Icon: Stethoscope, color: C.gold, bg: C.goldSoft, action: () => setScreen("seedoc") },
                { label: t.knowProblem, sub: t.knowProblemSub, Icon: MessageCircle, color: C.teal, bg: C.tealSoft, action: () => setScreen("ai") },
                { label: t.seeConsultant, sub: t.seeConsultantSub, Icon: User, color: C.purple, bg: C.purpleSoft, action: () => setScreen("consultant") },
                { label: t.walkIn, sub: t.walkInSub, Icon: Clock, color: C.amber, bg: C.amberSoft, action: () => setScreen("walkin") },
              ].map((o, i) => (
                <button key={i} className="tap" onClick={o.action || (() => {})} style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 14, marginBottom: 10, cursor: "pointer" }}>
                  <div style={{ width: 40, height: 40, borderRadius: 11, background: o.bg, display: "flex", alignItems: "center", justifyContent: "center", color: o.color, flexShrink: 0 }}><o.Icon size={18} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>{o.label}</div>
                    <div style={{ fontSize: 11.5, color: C.muted }}>{o.sub}</div>
                  </div>
                  <ChevronRight size={16} color={C.faint} />
                </button>
              ))}
            </div>
          )}

          {screen === "ai" && (
            <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 500 }}>
              <div style={{ fontSize: 11, color: C.faint, background: C.raised, borderRadius: 10, padding: 9, marginBottom: 12, lineHeight: 1.4 }}>{t.aiDisclaimer}</div>
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 9, overflowY: "auto" }}>
                {chat.map((m, i) => (
                  <div key={i} className="fadein" style={{ alignSelf: m.from === "ai" ? "flex-start" : "flex-end", maxWidth: "82%" }}>
                    <div style={{ background: m.from === "ai" ? C.surface : C.gold, color: m.from === "ai" ? C.text : "#1a1408", border: m.from === "ai" ? `1px solid ${C.border}` : "none", borderRadius: 15, padding: "9px 12px", fontSize: 13 }}>{m.text}</div>
                  </div>
                ))}
                {suggested && (
                  <div className="fadein" style={{ background: C.tealSoft, border: `1px solid ${C.teal}55`, borderRadius: 15, padding: 13 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5 }}>{suggested.name}</div>
                    <div style={{ fontSize: 11.5, color: C.muted, marginBottom: 9 }}>{lang === "hi" ? suggested.specHi : suggested.spec}</div>
                    <button className="tap" onClick={() => setScreen("home")} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 11, padding: "9px 12px", fontSize: 12.5, fontWeight: 700, cursor: "pointer" }}>{t.aiBook}</button>
                  </div>
                )}
              </div>
              <div style={{ display: "flex", gap: 7, marginTop: 10 }}>
                <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === "Enter" && sendChat()} placeholder={t.aiPlaceholder}
                  style={{ flex: 1, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "10px 12px", color: C.text, fontSize: 13, fontFamily: "inherit" }} />
                <button className="tap" onClick={sendChat} style={{ background: C.teal, border: "none", borderRadius: 12, width: 40, cursor: "pointer" }}><Send size={15} color="#0A0A0C" style={{ margin: "auto" }} /></button>
              </div>
            </div>
          )}

          {screen === "vault" && (
            <div className="fadein">
              <div style={{ fontSize: 20, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 4 }}>{t.vault}</div>
              <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 18 }}>{t.vaultSub}</div>
              {["Blood Test — CBC.pdf", "Chest X-Ray.jpg", "Prescription — 12 Aug.pdf"].map((f, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: 12, marginBottom: 8 }}>
                  <FileText size={16} color={C.gold} /><div style={{ flex: 1, fontSize: 12.5 }}>{f}</div><Lock size={13} color={C.faint} />
                </div>
              ))}
              <div style={{ marginTop: 10, fontSize: 11, color: C.faint, lineHeight: 1.5 }}>
                {lang === "hi" ? "यह वॉल्ट निजी है — डॉक्टर इसे तभी देख सकते हैं जब आप अनुमति दें।" : "This vault is private — doctors can only view it once you grant access."}
              </div>
            </div>
          )}

          {screen === "seedoc" && (
            <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
              <div style={{ fontSize: 20, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 4 }}>{t.seeDoc}</div>
              <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 18 }}>{t.seeDocSub}</div>
              <div style={{ flex: 1, overflowY: "auto" }}>
                {DOCTOR_LIST.map((d, i) => {
                  const wait = d.ahead * d.avg;
                  return (
                    <div key={i} style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 14, marginBottom: 10 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <div>
                          <div style={{ fontSize: 14, fontWeight: 600 }}>{d.name}</div>
                          <div style={{ fontSize: 11.5, color: C.muted, marginTop: 2 }}>{lang === "hi" ? d.specHi : d.spec}</div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 4, color: C.gold, fontSize: 12.5, fontWeight: 600, fontFamily: "'JetBrains Mono'" }}>
                            <Clock size={11} />{wait} {t.min}
                          </div>
                          <div style={{ color: C.faint, fontSize: 10, marginTop: 2 }}>{t.estWait}</div>
                        </div>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
                        <div style={{ color: C.faint, fontSize: 10.5 }}>{d.ahead} {t.doctorsToday}</div>
                        <button className="tap" onClick={() => { setBookedWith({ name: d.name, spec: d.spec, specHi: d.specHi }); setScreen("booked"); }}
                          style={{ background: C.raised, border: `1px solid ${C.border}`, color: C.text, fontSize: 11.5, fontWeight: 600, borderRadius: 10, padding: "7px 11px", cursor: "pointer" }}>
                          {t.bookNow}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {screen === "consultant" && (
            <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
              <div style={{ width: 48, height: 48, borderRadius: 13, background: C.purpleSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.purple, marginBottom: 16 }}>
                <User size={22} />
              </div>
              <div style={{ fontSize: 20, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 8 }}>{t.consultTitle}</div>
              <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.55, marginBottom: 20 }}>{t.consultBody}</div>
              <div style={{ flex: 1 }} />
              <button className="tap" onClick={() => { setBookedWith({ name: lang === "hi" ? "अगले उपलब्ध चिकित्सक" : "Next available physician", spec: "", specHi: "" }); setScreen("booked"); }}
                style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}>
                {t.consultCta}<ChevronRight size={16} />
              </button>
            </div>
          )}

          {screen === "walkin" && (
            <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
              <div style={{ width: 48, height: 48, borderRadius: 13, background: C.amberSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.amber, marginBottom: 16 }}>
                <Clock size={22} />
              </div>
              <div style={{ fontSize: 20, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 8 }}>{t.walkIn}</div>
              <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.55, marginBottom: 18 }}>{t.walkInSub}</div>
              {DEPARTMENTS.map((d, i) => (
                <button key={i} className="tap" onClick={() => { setBookedWith({ name: lang === "hi" ? d.nameHi : d.name, spec: "", specHi: "", isWalkin: true, waiting: d.waiting }); setScreen("booked"); }}
                  style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", textAlign: "left", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 13, marginBottom: 9, cursor: "pointer" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{lang === "hi" ? d.nameHi : d.name}</div>
                    <div style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>{d.waiting} {lang === "hi" ? "प्रतीक्षा में" : "waiting"}</div>
                  </div>
                  <ChevronRight size={15} color={C.faint} />
                </button>
              ))}
            </div>
          )}

          {screen === "booked" && (
            <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
              <div style={{ flex: 1 }} />
              <div style={{ alignSelf: "center", width: 64, height: 64, borderRadius: "50%", background: C.tealSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.teal, marginBottom: 16 }}>
                <Check size={28} />
              </div>
              <div style={{ textAlign: "center", fontSize: 19, fontWeight: 600, fontFamily: FONT_DISPLAY, marginBottom: 5 }}>{t.booked}</div>
              <div style={{ textAlign: "center", color: C.muted, fontSize: 12.5, marginBottom: 18 }}>{t.bookedSub}</div>
              {bookedWith && (
                <Card style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 14.5, fontWeight: 600 }}>{bookedWith.name}</div>
                  {(lang === "hi" ? bookedWith.specHi : bookedWith.spec) && <div style={{ fontSize: 11.5, color: C.muted, marginTop: 3 }}>{lang === "hi" ? bookedWith.specHi : bookedWith.spec}</div>}
                  {bookedWith.isWalkin && <div style={{ fontSize: 11.5, color: C.amber, marginTop: 6 }}>{bookedWith.waiting} {t.doctorsToday}</div>}
                </Card>
              )}
              <div style={{ flex: 1 }} />
              <button className="tap" onClick={() => setScreen("home")} style={{ width: "100%", background: C.raised, border: `1px solid ${C.border}`, color: C.text, borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 600, cursor: "pointer" }}>{t.doneClose}</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ==================================================================================
function DoctorView({ t, lang, queue, currentIdx, callNext, rollingAvg, vaultAccess, vaultRequesting, setVaultRequesting, setVaultAccess, markPriority }) {
  const current = queue[currentIdx];
  const waitingCount = queue.filter(q => q.status === "waiting").length;
  const completedCount = queue.filter(q => q.status === "completed").length;

  const requestAccess = () => {
    setVaultRequesting(true);
    setTimeout(() => { setVaultRequesting(false); setVaultAccess(true); }, 1100);
  };

  return (
    <div className="fadein">
      <div style={{ fontSize: 12, color: C.muted }}>{t.goodMorning}</div>
      <div style={{ fontSize: 24, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 20 }}>Dr. Sharma</div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 20 }}>
        {[
          { label: t.patients, value: queue.length, color: C.text },
          { label: t.completed, value: completedCount, color: C.green },
          { label: t.waiting, value: waitingCount, color: C.amber },
          { label: t.noShow, value: 0, color: C.faint },
        ].map((s, i) => (
          <Card key={i} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 24, fontWeight: 700, fontFamily: "'JetBrains Mono'", color: s.color }}>{s.value}</div>
            <div style={{ fontSize: 11, color: C.muted, marginTop: 4 }}>{s.label}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 16 }}>
        {/* Next patient panel */}
        <Card>
          <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 }}>{t.currentToken}</div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 26, fontWeight: 700, color: C.gold, fontFamily: "'JetBrains Mono'" }}>#{current?.tokenNum}</div>
              <div style={{ fontSize: 15, fontWeight: 600, marginTop: 4 }}>{current?.name}</div>
              <div style={{ fontSize: 12, color: C.muted }}>{current?.age} {lang === "hi" ? "वर्ष" : "yrs"}</div>
            </div>
            {current?.priority === "priority" && <StatusPill label={t.priority} color={C.red} bg={C.redSoft} />}
          </div>

          {current?.isDemoPatient ? (
            <div style={{ background: C.void, border: `1px solid ${C.border}`, borderRadius: 12, padding: 12, marginBottom: 12 }}>
              {!vaultAccess && !vaultRequesting && (
                <button className="tap" onClick={requestAccess} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: C.tealSoft, color: C.teal, border: `1px solid ${C.teal}44`, borderRadius: 10, padding: "10px 12px", fontSize: 12.5, fontWeight: 600, cursor: "pointer" }}>
                  <Lock size={14} />{t.requestAccess}
                </button>
              )}
              {vaultRequesting && (
                <div style={{ display: "flex", alignItems: "center", gap: 8, color: C.muted, fontSize: 12.5, justifyContent: "center", padding: "10px 0" }}>
                  <Bell size={14} className="fadein" />{t.accessPending}
                </div>
              )}
              {vaultAccess && (
                <div className="fadein">
                  <div style={{ display: "flex", alignItems: "center", gap: 7, color: C.green, fontSize: 12, fontWeight: 600, marginBottom: 10 }}><Unlock size={13} />{t.accessGranted}</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, fontSize: 12 }}>
                    <div><div style={{ color: C.faint, fontSize: 10.5 }}>{t.chiefComplaint}</div><div>{lang === "hi" ? "3 दिन से बुखार व कमज़ोरी" : "Fever & weakness, 3 days"}</div></div>
                    <div><div style={{ color: C.faint, fontSize: 10.5 }}>{t.allergy}</div><div>Penicillin</div></div>
                    <div><div style={{ color: C.faint, fontSize: 10.5 }}>{t.knownConditions}</div><div>Hypertension</div></div>
                    <div><div style={{ color: C.faint, fontSize: 10.5 }}>{t.reports}</div><div>3 {lang === "hi" ? "उपलब्ध" : "available"}</div></div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ fontSize: 12, color: C.faint, marginBottom: 12 }}>{lang === "hi" ? "कोई अतिरिक्त वॉल्ट डेटा उपलब्ध नहीं" : "No additional vault data available for demo"}</div>
          )}

          <button className="tap" onClick={callNext} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 12, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}>
            <CheckCircle2 size={16} />{t.complete} → {t.nextPatient}
          </button>
        </Card>

        {/* Queue list */}
        <Card style={{ maxHeight: 360, overflowY: "auto" }}>
          <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 }}>{t.queue}</div>
          {queue.map((q, i) => (
            <div key={q.tokenNum} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: i < queue.length - 1 ? `1px solid ${C.border}` : "none", opacity: q.status === "completed" ? 0.45 : 1 }}>
              <div style={{ width: 34, fontFamily: "'JetBrains Mono'", fontSize: 12.5, fontWeight: 700, color: i === currentIdx ? C.gold : C.text }}>#{q.tokenNum}</div>
              <div style={{ flex: 1, fontSize: 12.5 }}>{q.name}{q.isDemoPatient && <span style={{ color: C.faint }}> · demo</span>}</div>
              {q.status === "completed" && <CheckCircle2 size={14} color={C.green} />}
              {i === currentIdx && q.status !== "completed" && <StatusPill label={lang === "hi" ? "अभी" : "now"} color={C.amber} bg={C.amberSoft} />}
              {q.priority === "priority" && q.status === "waiting" && <StatusPill label={t.priority} color={C.red} bg={C.redSoft} />}
              {q.status === "waiting" && q.priority !== "priority" && (
                <button className="tap" onClick={() => markPriority(i)} title={t.markPriority} style={{ background: "none", border: `1px solid ${C.border}`, borderRadius: 8, padding: "3px 7px", cursor: "pointer", color: C.faint }}>
                  <AlertTriangle size={11} />
                </button>
              )}
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

// ==================================================================================
function AdminView({ t, lang, queue, currentIdx, rollingAvg }) {
  const waitingCount = queue.filter(q => q.status === "waiting").length;
  const completedCount = queue.filter(q => q.status === "completed").length;

  const [roster, setRoster] = useState([
    { name: "Dr. Sharma", dept: "General Medicine", deptHi: "जनरल मेडिसिन", status: "available" },
    { name: "Dr. Anjali Rao", dept: "Cardiology", deptHi: "हृदय रोग", status: "available" },
    { name: "Dr. Meera Iyer", dept: "Dermatology", deptHi: "त्वचा रोग", status: "available" },
    { name: "Dr. Farhan Ali", dept: "Orthopedics", deptHi: "हड्डी रोग", status: "leave" },
    { name: "Dr. Priya Nair", dept: "Pediatrics", deptHi: "बाल रोग", status: "available" },
  ]);
  const toggleLeave = (i) => setRoster(r => r.map((d, idx) => idx === i ? { ...d, status: d.status === "available" ? "leave" : "available" } : d));
  const onLeaveCount = roster.filter(d => d.status === "leave").length;

  const [pending, setPending] = useState([
    { id: 1, name: "Dr. Karan Mehta", spec: "Neurology", specHi: "न्यूरोलॉजी", reg: "MCI-88213" },
    { id: 2, name: "Dr. Simran Kaur", spec: "ENT", specHi: "ईएनटी", reg: "MCI-91027" },
  ]);
  const resolvePending = (id) => setPending(p => p.filter(x => x.id !== id));

  const [depts, setDepts] = useState(DEPARTMENTS.map(d => ({ ...d })));
  const adjustLoad = (i, delta) => setDepts(ds => ds.map((d, idx) => idx === i ? { ...d, waiting: Math.max(0, d.waiting + delta) } : d));
  const busiest = depts.reduce((a, b) => (b.waiting > a.waiting ? b : a), depts[0]);

  return (
    <div className="fadein">
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: C.green }} />
        <div style={{ fontSize: 11, color: C.green, fontWeight: 700, letterSpacing: 1 }}>{t.live}</div>
      </div>
      <div style={{ fontSize: 24, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 20 }}>{t.liveHospital}</div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12, marginBottom: 20 }}>
        {[
          { label: t.patients + " (" + t.today + ")", value: 1248, Icon: Users },
          { label: t.currentlyWaiting, value: depts.reduce((s, d) => s + d.waiting, 0), Icon: Clock, color: C.amber },
          { label: t.doctorsAvailable, value: 42 - onLeaveCount, Icon: Stethoscope, color: C.green },
          { label: t.onLeave, value: onLeaveCount, Icon: XCircle, color: C.faint },
          { label: t.avgWait, value: `31 ${t.min}`, Icon: TrendingUp, color: C.teal },
        ].map((s, i) => (
          <Card key={i}>
            <s.Icon size={16} color={s.color || C.muted} style={{ marginBottom: 8 }} />
            <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "'JetBrains Mono'", color: s.color || C.text }}>{s.value}</div>
            <div style={{ fontSize: 10.5, color: C.muted, marginTop: 3 }}>{s.label}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 16, marginBottom: 16 }}>
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: 1 }}>{t.departmentLoad}</div>
            <StatusPill label={`${t.mostCrowded}: ${lang === "hi" ? busiest.nameHi : busiest.name}`} color={C.red} bg={C.redSoft} />
          </div>
          {depts.map((d, i) => {
            const pct = Math.min(100, (d.waiting / 14) * 100);
            return (
              <div key={i} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12.5, marginBottom: 5 }}>
                  <span>{lang === "hi" ? d.nameHi : d.name}</span>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ color: C.muted }}>{d.waiting} {lang === "hi" ? "प्रतीक्षा में" : "waiting"} · {d.doctorsOn} {lang === "hi" ? "डॉक्टर" : "on"}</span>
                    <button className="tap" onClick={() => adjustLoad(i, -1)} style={{ width: 20, height: 20, borderRadius: 6, background: C.raised, border: `1px solid ${C.border}`, color: C.text, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Minus size={11} /></button>
                    <button className="tap" onClick={() => adjustLoad(i, 1)} style={{ width: 20, height: 20, borderRadius: 6, background: C.raised, border: `1px solid ${C.border}`, color: C.text, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={11} /></button>
                  </div>
                </div>
                <div style={{ height: 6, background: C.raised, borderRadius: 3, overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: pct > 70 ? C.red : pct > 40 ? C.amber : C.green, borderRadius: 3, transition: "width .25s ease" }} />
                </div>
              </div>
            );
          })}
        </Card>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <Card>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>{t.labQueue}</div>
            <div style={{ fontSize: 22, fontWeight: 700, fontFamily: "'JetBrains Mono'", color: C.amber }}>38</div>
          </Card>
          <Card>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>{t.pharmQueue}</div>
            <div style={{ fontSize: 22, fontWeight: 700, fontFamily: "'JetBrains Mono'", color: C.teal }}>27</div>
          </Card>
          <Card>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>General Medicine — {t.queue}</div>
            <div style={{ fontSize: 12.5, color: C.text }}>{t.currentToken}: <b style={{ color: C.gold, fontFamily: "'JetBrains Mono'" }}>#{queue[currentIdx]?.tokenNum}</b></div>
            <div style={{ fontSize: 12.5, color: C.text, marginTop: 4 }}>{t.waiting}: <b>{waitingCount}</b> &nbsp; {t.completed}: <b>{completedCount}</b></div>
          </Card>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <Card>
          <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 }}>{t.doctorRoster}</div>
          {roster.map((d, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: i < roster.length - 1 ? `1px solid ${C.border}` : "none" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600 }}>{d.name}</div>
                <div style={{ fontSize: 11, color: C.muted }}>{lang === "hi" ? d.deptHi : d.dept}</div>
              </div>
              <StatusPill label={d.status === "available" ? (lang === "hi" ? "उपलब्ध" : "Available") : t.onLeave} color={d.status === "available" ? C.green : C.faint} bg={d.status === "available" ? C.greenSoft : C.raised} />
              <button className="tap" onClick={() => toggleLeave(i)} style={{ background: C.raised, border: `1px solid ${C.border}`, borderRadius: 9, padding: "5px 9px", fontSize: 10.5, fontWeight: 600, color: C.text, cursor: "pointer", whiteSpace: "nowrap" }}>
                {d.status === "available" ? t.markLeave : t.markAvailable}
              </button>
            </div>
          ))}
        </Card>

        <Card>
          <div style={{ fontSize: 11, color: C.muted, textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 }}>{t.pendingApprovals}</div>
          {pending.length === 0 && <div style={{ fontSize: 12.5, color: C.faint, padding: "10px 0" }}>{t.noPendingApprovals}</div>}
          {pending.map(p => (
            <div key={p.id} className="fadein" style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: `1px solid ${C.border}` }}>
              <div style={{ width: 32, height: 32, borderRadius: 9, background: C.amberSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.amber, flexShrink: 0 }}><UserPlus size={15} /></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600 }}>{p.name}</div>
                <div style={{ fontSize: 10.5, color: C.muted }}>{lang === "hi" ? p.specHi : p.spec} · {p.reg}</div>
              </div>
              <button className="tap" onClick={() => resolvePending(p.id)} style={{ background: C.greenSoft, border: `1px solid ${C.green}44`, color: C.green, borderRadius: 8, padding: "5px 8px", fontSize: 10.5, fontWeight: 700, cursor: "pointer" }}>{t.approve}</button>
              <button className="tap" onClick={() => resolvePending(p.id)} style={{ background: C.redSoft, border: `1px solid ${C.red}44`, color: C.red, borderRadius: 8, padding: "5px 8px", fontSize: 10.5, fontWeight: 700, cursor: "pointer" }}>{t.reject}</button>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

// ==================================================================================
function DisplayView({ t, lang, queue, currentIdx }) {
  const current = queue[currentIdx];
  const nextOne = queue[currentIdx + 1];
  return (
    <div className="fadein" style={{ background: "#000", borderRadius: 20, border: `1px solid ${C.border}`, padding: "48px 40px", textAlign: "center" }}>
      <div style={{ fontSize: 13, letterSpacing: 3, color: C.gold, textTransform: "uppercase", fontWeight: 700, marginBottom: 6 }}>General Medicine</div>
      <div style={{ fontSize: 12, color: C.faint, marginBottom: 40 }}>OPD Room 204 · Floor 2</div>

      <div style={{ display: "flex", justifyContent: "center", gap: 60, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 15, color: C.muted, letterSpacing: 2, marginBottom: 10 }}>{t.nowServing}</div>
          <div style={{ fontSize: 96, fontWeight: 700, fontFamily: "'JetBrains Mono'", color: C.text, lineHeight: 1 }}>#{current?.tokenNum ?? "--"}</div>
        </div>
        <div style={{ width: 1, background: C.border }} />
        <div>
          <div style={{ fontSize: 15, color: C.muted, letterSpacing: 2, marginBottom: 10 }}>{t.next}</div>
          <div style={{ fontSize: 64, fontWeight: 700, fontFamily: "'JetBrains Mono'", color: C.faint, lineHeight: 1 }}>#{nextOne?.tokenNum ?? "--"}</div>
        </div>
      </div>

      <div style={{ marginTop: 44, display: "flex", justifyContent: "center", gap: 8 }}>
        {[current, nextOne].filter(Boolean).map((q, i) => (
          <StatusPill key={i} label={i === 0 ? (lang === "hi" ? "परामर्श में" : "In consultation") : t.waiting} color={i === 0 ? C.green : C.amber} bg={i === 0 ? C.greenSoft : C.amberSoft} />
        ))}
      </div>
    </div>
  );
}

// ==================================================================================
// REGISTRATION / ONBOARDING — runs before the main app
// ==================================================================================
function Onboarding({ lang, setLang, onDone }) {
  const t = STR[lang];
  const [screen, setScreen] = useState("role"); // role, mobile, otp, personal, history (patient) | docinfo, pending (doctor)
  const [role, setRole] = useState(null);
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [form, setForm] = useState({ name: "", age: "", sex: "", blood: "", emergency: "" });
  const [scanned, setScanned] = useState([]);
  const [docForm, setDocForm] = useState({ name: "", qualification: "", specialization: "", regNumber: "", stateCouncil: "", experience: "", hospitalAffiliation: "", department: "" });

  const backMap = {
    mobile: "role", otp: "mobile",
    personal: "otp", history: "personal",
    docinfo: "otp", pending: "docinfo",
  };
  const backTarget = backMap[screen];

  const goAfterOtp = () => setScreen(role === "doctor" ? "docinfo" : "personal");

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: `radial-gradient(120% 120% at 50% 0%, #1a1a1e 0%, ${C.void} 55%)`, fontFamily: FONT_BODY, color: C.text, padding: 20 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        input:focus, button:focus { outline: none; }
        .fadein { animation: fadein .3s ease both; }
        @keyframes fadein { from { opacity:0; transform: translateY(6px);} to {opacity:1; transform:none;} }
        .tap { transition: transform .12s ease, background .15s ease; }
        .tap:active { transform: scale(0.97); }
      `}</style>
      <PhoneShell>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          {screen !== "role" ? (
            <button className="tap" onClick={() => setScreen(backTarget)} style={{ background: C.raised, border: `1px solid ${C.border}`, borderRadius: 10, width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", color: C.text, cursor: "pointer" }}>
              <ChevronLeft size={17} />
            </button>
          ) : <div />}
          <div style={{ display: "flex", background: C.raised, border: `1px solid ${C.border}`, borderRadius: 20, padding: 3 }}>
            {["en", "hi"].map(l => (
              <button key={l} className="tap" onClick={() => setLang(l)} style={{
                border: "none", cursor: "pointer", borderRadius: 16, padding: "5px 10px", fontSize: 11.5, fontWeight: 600,
                background: lang === l ? C.gold : "transparent", color: lang === l ? "#1a1408" : C.muted,
              }}>{l === "en" ? "EN" : "हिं"}</button>
            ))}
          </div>
        </div>

        {screen === "role" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ flex: 1 }} />
            <div style={{ fontSize: 26, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 6 }}>{t.whoAmI}</div>
            <div style={{ fontSize: 13, color: C.muted, marginBottom: 22 }}>{t.whoSub}</div>
            {[
              { key: "patient", label: t.patientRole, sub: t.patientRoleSub, Icon: User },
              { key: "doctor", label: t.doctorRole, sub: t.doctorRoleSub, Icon: Stethoscope },
            ].map(r => (
              <button key={r.key} className="tap" onClick={() => { setRole(r.key); setScreen("mobile"); }}
                style={{ display: "flex", alignItems: "center", gap: 14, textAlign: "left", width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 16, marginBottom: 12, cursor: "pointer" }}>
                <div style={{ width: 46, height: 46, borderRadius: 12, background: C.goldSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.gold, flexShrink: 0 }}><r.Icon size={22} /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>{r.label}</div>
                  <div style={{ fontSize: 12, color: C.muted, marginTop: 2 }}>{r.sub}</div>
                </div>
                <ChevronRight size={18} color={C.faint} />
              </button>
            ))}
            <div style={{ flex: 1 }} />
          </div>
        )}

        {screen === "mobile" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ width: 50, height: 50, borderRadius: 13, background: C.tealSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.teal, marginBottom: 16 }}><Phone size={22} /></div>
            <div style={{ fontSize: 22, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 5 }}>{t.mobileTitle}</div>
            <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 18 }}>{t.mobileSub}</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
              <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 13px", color: C.muted, fontSize: 14 }}>+91</div>
              <input value={mobile} onChange={e => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))} placeholder="98765 43210"
                style={{ flex: 1, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 13px", color: C.text, fontSize: 14, fontFamily: "inherit" }} />
            </div>
            <div style={{ flex: 1 }} />
            <button className="tap" onClick={() => setScreen("otp")} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>{t.sendOtp}</button>
          </div>
        )}

        {screen === "otp" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ fontSize: 22, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 5 }}>{t.otpTitle}</div>
            <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 18 }}>{t.otpSub} +91 {mobile || "98765 43210"}</div>
            <div style={{ display: "flex", gap: 7, marginBottom: 18, justifyContent: "space-between" }}>
              {[0, 1, 2, 3, 4, 5].map(i => (
                <div key={i} style={{ width: 42, height: 50, borderRadius: 10, background: C.surface, border: `1px solid ${otp.length > i ? C.gold : C.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, fontFamily: "'JetBrains Mono'" }}>{otp[i] || ""}</div>
              ))}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
              {["1","2","3","4","5","6","7","8","9","","0","⌫"].map((k, i) => (
                <button key={i} className="tap" disabled={k === ""} onClick={() => { if (k === "⌫") setOtp(o => o.slice(0, -1)); else if (k !== "") setOtp(o => (o + k).slice(0, 6)); }}
                  style={{ visibility: k === "" ? "hidden" : "visible", background: C.raised, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 0", color: C.text, fontSize: 15, cursor: "pointer" }}>{k}</button>
              ))}
            </div>
            <div style={{ flex: 1 }} />
            <button className="tap" onClick={goAfterOtp} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>{t.verify}</button>
          </div>
        )}

        {screen === "personal" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ fontSize: 22, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 5 }}>{t.personalTitle}</div>
            <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 16 }}>{t.personalSub}</div>
            <Field label={t.nameField} value={form.name} onChange={v => setForm({ ...form, name: v })} placeholder={lang === "hi" ? "जैसे रोहन शर्मा" : "e.g. Rohan Sharma"} />
            <div style={{ display: "flex", gap: 10 }}>
              <div style={{ flex: 1 }}><Field label={t.ageField} value={form.age} onChange={v => setForm({ ...form, age: v.replace(/\D/g, "") })} placeholder="28" /></div>
              <div style={{ flex: 1 }}><Field label={t.sexField} value={form.sex} onChange={v => setForm({ ...form, sex: v })} placeholder={lang === "hi" ? "पुरुष/महिला" : "M/F/Other"} /></div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <div style={{ flex: 1 }}><Field label={t.bloodField} value={form.blood} onChange={v => setForm({ ...form, blood: v })} placeholder="O+" /></div>
              <div style={{ flex: 1 }}><Field label={t.emergencyField} value={form.emergency} onChange={v => setForm({ ...form, emergency: v.replace(/\D/g, "").slice(0, 10) })} placeholder="98xxxxxxxx" /></div>
            </div>
            <div style={{ flex: 1 }} />
            <button className="tap" onClick={() => setScreen("history")} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>{t.continueBtn}</button>
          </div>
        )}

        {screen === "history" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ fontSize: 22, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 5 }}>{t.historyTitle}</div>
            <div style={{ fontSize: 12.5, color: C.muted, marginBottom: 16 }}>{t.historySub}</div>
            <button className="tap" onClick={() => setScanned(s => [...s, { id: Date.now(), name: lang === "hi" ? `रिपोर्ट ${s.length + 1}` : `Report ${s.length + 1}.pdf` }])}
              style={{ border: `1.5px dashed ${C.border}`, borderRadius: 16, padding: "20px 16px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, background: C.surface, cursor: "pointer", marginBottom: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, background: C.tealSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.teal }}><Upload size={19} /></div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{t.scanDoc}</div>
            </button>
            {scanned.map(s => (
              <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 11px", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 7 }}>
                <FileText size={15} color={C.gold} /><div style={{ flex: 1, fontSize: 12.5 }}>{s.name}</div><Check size={14} color={C.teal} />
              </div>
            ))}
            <div style={{ flex: 1 }} />
            <button className="tap" onClick={() => onDone(form.name.trim() || "Rahul Kumar", "patient")} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>{t.finish}</button>
            <div style={{ height: 8 }} />
            <button onClick={() => onDone(form.name.trim() || "Rahul Kumar", "patient")} style={{ background: "none", border: "none", color: C.faint, fontSize: 12, padding: 6, cursor: "pointer" }}>{t.skipForNow}</button>
          </div>
        )}

        {screen === "docinfo" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ fontSize: 20, fontFamily: FONT_DISPLAY, fontWeight: 500, marginBottom: 5 }}>{t.professionalTitle}</div>
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 16 }}>{t.professionalSub}</div>
            <div style={{ maxHeight: 430, overflowY: "auto", paddingRight: 2 }}>
              <Field label={t.nameField} value={docForm.name} onChange={v => setDocForm({ ...docForm, name: v })} placeholder={lang === "hi" ? "जैसे डॉ. आर. शर्मा" : "e.g. Dr. R. Sharma"} />
              <div style={{ display: "flex", gap: 10 }}>
                <div style={{ flex: 1 }}><Field label={t.qualification} value={docForm.qualification} onChange={v => setDocForm({ ...docForm, qualification: v })} placeholder="MBBS, MD" /></div>
                <div style={{ flex: 1 }}><Field label={t.specialization} value={docForm.specialization} onChange={v => setDocForm({ ...docForm, specialization: v })} placeholder={lang === "hi" ? "जनरल मेडिसिन" : "General Medicine"} /></div>
              </div>
              <Field label={t.regNumber} value={docForm.regNumber} onChange={v => setDocForm({ ...docForm, regNumber: v })} placeholder="MCI-123456" />
              <div style={{ display: "flex", gap: 10 }}>
                <div style={{ flex: 1 }}><Field label={t.stateCouncil} value={docForm.stateCouncil} onChange={v => setDocForm({ ...docForm, stateCouncil: v })} placeholder={lang === "hi" ? "उत्तर प्रदेश" : "Uttar Pradesh"} /></div>
                <div style={{ flex: 1 }}><Field label={t.experience} value={docForm.experience} onChange={v => setDocForm({ ...docForm, experience: v.replace(/\D/g, "") })} placeholder="8" /></div>
              </div>
              <Field label={t.hospitalAffiliation} value={docForm.hospitalAffiliation} onChange={v => setDocForm({ ...docForm, hospitalAffiliation: v })} placeholder={lang === "hi" ? "सिटी हॉस्पिटल, मेरठ" : "City Hospital, Meerut"} />
              <Field label={t.department} value={docForm.department} onChange={v => setDocForm({ ...docForm, department: v })} placeholder={lang === "hi" ? "जनरल मेडिसिन" : "General Medicine"} />
            </div>
            <div style={{ flex: 1 }} />
            <button className="tap" onClick={() => setScreen("pending")} style={{ width: "100%", background: C.gold, color: "#1a1408", border: "none", borderRadius: 14, padding: "13px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>{t.submitForVerification}</button>
          </div>
        )}

        {screen === "pending" && (
          <div className="fadein" style={{ display: "flex", flexDirection: "column", flex: 1 }}>
            <div style={{ flex: 1 }} />
            <div style={{ alignSelf: "center", width: 60, height: 60, borderRadius: "50%", background: C.amberSoft, display: "flex", alignItems: "center", justifyContent: "center", color: C.amber, marginBottom: 18 }}>
              <Clock size={26} />
            </div>
            <div style={{ textAlign: "center", fontSize: 19, fontWeight: 600, fontFamily: FONT_DISPLAY, marginBottom: 8 }}>{t.pendingTitle}</div>
            <div style={{ textAlign: "center", fontSize: 12.5, color: C.muted, lineHeight: 1.55, marginBottom: 18 }}>{t.pendingSub}</div>
            <Card style={{ marginBottom: 18 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{docForm.name || "Dr. —"}</div>
              <div style={{ fontSize: 11.5, color: C.muted, marginTop: 2, marginBottom: 8 }}>{docForm.specialization || t.specialization} · {docForm.hospitalAffiliation || t.hospitalAffiliation}</div>
              <StatusPill label={t.pendingBadge} color={C.amber} bg={C.amberSoft} />
            </Card>
            <div style={{ flex: 1 }} />
            <button className="tap" onClick={() => onDone(docForm.name.trim() || "Dr. Sharma", "doctor")} style={{ width: "100%", background: C.raised, border: `1px solid ${C.border}`, color: C.text, borderRadius: 14, padding: "13px 14px", fontSize: 12.5, fontWeight: 600, cursor: "pointer" }}>{t.simulateApproval}</button>
          </div>
        )}
      </PhoneShell>
    </div>
  );
}

// ==================================================================================
export default function Root() {
  const [lang, setLang] = useState("en");
  const [stage, setStage] = useState("onboarding"); // onboarding | app
  const [patientName, setPatientName] = useState("Rahul Kumar");
  const [initialTab, setInitialTab] = useState("patient");

  if (stage === "onboarding") {
    return <Onboarding lang={lang} setLang={setLang} onDone={(name, role) => { setPatientName(name); setInitialTab(role === "doctor" ? "doctor" : "patient"); setStage("app"); }} />;
  }
  return <MainApp lang={lang} setLang={setLang} initialName={patientName} initialTab={initialTab} />;
}
