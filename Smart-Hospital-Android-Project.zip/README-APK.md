# Smart Hospital — Android APK

This is the React/Vite version of the supplied `smart-hospital-demo.jsx`, wrapped for Android with Capacitor.

## Build the APK on Windows

1. Install Node.js LTS and Android Studio.
2. Open this folder in VS Code/PowerShell.
3. Run:

   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android

4. In Android Studio, wait for Gradle sync.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Install the generated debug APK on your Android phone.

### Command-line alternative

After Android platform has been added and Android SDK/Java are configured:

   npm run android:build

The debug APK is normally produced under:

   android/app/build/outputs/apk/debug/app-debug.apk

## Notes

- The original UI/code is preserved in `src/App.jsx`.
- The app is a demo/prototype; it does not include a production backend or real hospital records.
